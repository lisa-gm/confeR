#' Nurses hom data (TO DO)
#'
#' A subset of data from the World Health Organization Global Tuberculosis
#' Report ...
#'
#' @format ## `nurses_hom`
#' \describe{
#'   \item{data_ipd}{A data frame with 1000 rows and 6 variables:
#'     \describe{
#'       \item{stress}{Standardized stress levels}
#'        ...
#'     }
#'   }
#'   \item{...}{...
#'     \describe{
#'          ...
#'     }
#'   }
#' }
"nurses_hom"
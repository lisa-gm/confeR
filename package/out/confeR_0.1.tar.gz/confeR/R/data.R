#' Nurses hom data
#'
#' This simulated data set consists of 1000 data points representing nurses from
#' 25 hospitals. The outcome of interest is job-related stress among nurses
#' (standardized) and the covariates are age (standardized), experience
#' (standardized), sex (0 = male, 1 = female), the type of ward in which the
#' nurse works (0 = general care, 1 = special care), and hospital (1, 2, ...,
#' 25).
#'
#' @docType data
#'
#' @name nurses_hom
#'
#' @format ## `nurses_hom`
#' A data frame with 7,240 rows and 60 columns:
#' \describe{
#'   \item{country}{Country name}
#'   \item{iso2, iso3}{2 & 3 letter ISO country codes}
#'   \item{year}{Year}
#'   ...
#' }
#'

"nurses_hom"